package com.test.web.api;

/**
 * Created by shenfl on 2018/6/15
 */
public interface TestApi {
}
